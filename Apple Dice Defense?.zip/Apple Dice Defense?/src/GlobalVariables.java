import acm.graphics.GPoint;
import acm.program.Program;

import javax.swing.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;

import static acm.util.JTFTools.pause;

public class GlobalVariables {
    static int[] v = new int[10];
    static boolean wave = false;
    static boolean FF = false;
    static volatile boolean enemiesLeft = false;
    static int waveN = 0;
    static int lives = 100;
    static GTile pickedUp;
    static ArrayList<GApple> enemies = new ArrayList<>();
    static int[][] waveData = {{1,1,2,3},{2,2,0,2},{2,1,1,5},{5,2,0,1},{1,1,1,10},{3,4,0,1},{5,2,2,4},{3,2,1,10},{20,2,0,1},{6,6,2,6},{20,1,1,5},{5,3,1,30},{100,3,0,1},{20,10,3,3},{20,3,1,50},{100,3,3,5},{250,4,0,1},{50,20,3,5},{250,4,3,5},{100,3,1,50},{500,5,0,1},{100,25,1,10},{10,4,0,300},{500,3,2,50},{2500,4,0,1}};
    static GTile[][] tiles = new GTile[20][10];
    static ArrayList<GProjectile> projectiles = new ArrayList<>();
    static ADD screen;
    static boolean starting = false;
    static int[] current;
    static ArrayList<GTile> path = new ArrayList<>();
    public static void tick(){
        for (int i = 0; i < enemies.size(); i++) {
            enemies.get(i).tick();
        }
        for (GTile[] someTiles: tiles) {
            for (GTile tile:someTiles) {
                tile.tick();
            }
        }
        for (int i = 0; i < projectiles.size(); i++) {
            projectiles.get(i).tick();
        }
        enemies.sort((o1, o2) -> {
            if (o1.pathAmount > o2.pathAmount){
                return -1;
            }
            else if (o2.pathAmount > o1.pathAmount){
                return 1;
            }
            else{
                if (o1.pathLeft < o2.pathLeft){
                    return -1;
                }
                else if (o2.pathLeft < o1.pathLeft) {
                    return 1;
                }
                return 0;
            }
        });
        screen.repaint();
    }
    public static boolean isNextTo(int x1, int y1, int x2, int y2){
        if (x2%2==1){
            if (y2 == y1-1){
                return Math.abs(x1 - x2) < 2;
            }
            else if (y2 == y1){
               return Math.abs(x1 - x2) == 1;
            }
            else if (y2-1 == y1){
                return x1 == x2;
            }
            else{
                return false;
            }
        }
        else{
            if (y2-1 == y1){
                return Math.abs(x1 - x2) < 2;
            }
            else if (y2 == y1){
                return Math.abs(x1 - x2) == 1;
            }
            else if (y2 == y1-1){
                return x1 == x2;
            }
            else{
                return false;
            }
        }
    }
    public static GPoint getPositionOf(int x, int y){
        GPoint p = new GPoint();
        p.setLocation(x*38,(y+((double)x%2/2))*50);
        return p;
    }
    public static int randomInt(int from, int to){
        return (int)(Math.random()*(to-from+1)) + from;
    }
    public static void startWave(){
        wave = true;
        enemiesLeft = true;
        if (waveN < waveData.length) {
            for (int i = 0; i < waveData[waveN][3]; i++) {
                GApple p = new GApple(waveData[waveN][0], waveData[waveN][1]);
                screen.addToScreen(p);
                for (int j = 0; j < 10 * GlobalVariables.waveData[waveN][2]; j++) {
                    tick();
                    if (FF) {
                        pause(10);
                    } else {
                        pause(25);
                    }
                }
            }
        }
        else{
            for (int i = 0; i < waveN; i++) {
                GApple p = new GApple(waveN*waveN*waveN/20,(int)Math.sqrt(waveN));
                screen.addToScreen(p);
                for (int j = 0; j < 25 * Math.pow(0.99,waveN); j++) {
                    tick();
                    if (FF) {
                        pause(10);
                    } else {
                        pause(25);
                    }
                }
            }
        }
        wave = false;
        while(enemiesLeft){
            tick();
            if (FF){
                pause(10);
            }
            else {
                pause(25);
            }
        }
        while(projectiles.size() > 0){
            projectiles.get(0).remove();
        }
        waveN++;
        screen.getADice();
    }
    public static void run2(){
        for (int i = 1; i < 11; i++) {
            GTile t = new GTile(50,((i-1)%5)+2,4+((i-1)/5),i);
            screen.addToScreen(t);
        }
        GTile[] z = new GTile[5];
        for (int i = 1; i < 6; i++) {
            GTile t = new GTile(50,i+2,2);
            screen.addToScreen(t);
            z[i-1] = t;
        }
        JButton j = new JButton("GO!");
        screen.add(j, Program.SOUTH);

        j.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                boolean exit = true;
                for (int i = 0; i < 5; i++) {
                    if (!z[i].dice){
                        exit = false;
                    }
                }
                if (exit) {
                    starting = true;
                    j.setVisible(false);
                    for (int i = 0; i < 3; i++) {
                        v[i] = z[0].diceType;
                    }
                    for (int i = 1; i < 4; i++) {
                        for (int k = (i*2) + 1; k < (i*2) + 3; k++) {
                            v[k] = z[i].diceType;
                        }
                    }
                    v[9] = z[4].diceType;
                    screen.removeAll();
                    screen.waveStarter = j;
                    j.removeMouseListener(this);
                    screen.run1();
                }
            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        });
    }
    public static void exsist(){
        new Thread(GlobalVariables::run2).start();
    }
}
