import acm.graphics.GLine;
import acm.graphics.GOval;

import java.awt.*;
import java.util.ArrayList;

public class GProjectile extends GMovable {
    GTile owner;
    ArrayList<GApple> hit = new ArrayList<>();
    GOval v = new GOval(7,7);
    GApple target;
    GTile targets;
    int type;
    int lvl;
    int pierceLeft;
    boolean out;
    public void tick(){
        repaint();
        if (type == 1){
            moveSteps(lvl);
            for (int i = 0; i < GlobalVariables.enemies.size(); i++) {
                GApple enemy = GlobalVariables.enemies.get(i);
                if (isTouching(enemy)){
                    if (pierceLeft > 0) {
                        enemy.life -= (lvl + (lvl/2) + (lvl/3) + (lvl/5))*enemy.vunrablility;
                        hit.add(enemy);
                        if (enemy.life < 1) {
                            enemy.remove();
                            i--;
                        }
                    }
                    pierceLeft--;
                    if (pierceLeft < 1){
                        this.remove();
                    }
                }
            }
        }
        else if (type == 2){
            if (pierceLeft == pierce()){
                moveTowards(target.getX(), target.getY(),lvl*2);
            }
            else{
                moveSteps(lvl*2);
            }
            for (int i = 0; i < GlobalVariables.enemies.size(); i++) {
                GApple enemy = GlobalVariables.enemies.get(i);
                if (isTouching(enemy)){
                    if (pierceLeft > 0) {
                        if (lvl > 2) {
                            enemy.life -= Math.pow(lvl - 2, 2)*enemy.vunrablility;
                        }
                        enemy.fire += lvl * Math.sqrt(lvl);
                        if (enemy.fireDmg < lvl) {
                            enemy.fireDmg = lvl;
                        }
                        hit.add(enemy);
                        if (enemy.life < 1) {
                            enemy.remove();
                            i--;
                        }
                    }
                    pierceLeft--;
                        if (pierceLeft < 1){
                            this.remove();
                        }
                }
            }
        }
        else if (type == 3){
            if (pierceLeft > 0) {
                moveTowards(target.getX(), target.getY(), lvl * 2);
                for (int i = 0; i < GlobalVariables.enemies.size(); i++) {
                    GApple enemy = GlobalVariables.enemies.get(i);
                    if (isTouching(enemy)) {
                        enemy.life -= lvl*enemy.vunrablility*((lvl/2)+1);
                        pierceLeft = 0;
                        hit.add(enemy);
                        if (enemy.life < 1) {
                            enemy.remove();
                            i--;
                        }
                    }
                }
            }
            else{
                setLocation(getX()-getWidth()*0.02,getY()-getHeight()*0.02);
                scale(1.04);
                for (int i = 0; i < GlobalVariables.enemies.size(); i++) {
                    GApple enemy = GlobalVariables.enemies.get(i);
                    if (isTouching(enemy)) {
                        enemy.life -= lvl*enemy.vunrablility*((lvl/2)+1);
                        hit.add(enemy);
                        if (enemy.life < 1) {
                            enemy.remove();
                            i--;
                        }
                    }
                }
                if (getWidth() > 24 + (25*lvl)){
                    remove();
                }
            }
        }
        else if (type == 4){
            if (pierceLeft == pierce()){
                moveTowards(target.getX(), target.getY(),lvl*3);
                for (int i = 0; i < GlobalVariables.enemies.size(); i++) {
                    GApple enemy = GlobalVariables.enemies.get(i);
                    if (isTouching(enemy)){
                            enemy.life -= Math.pow(1.5,pierceLeft)*target.vunrablility;
                            hit.add(enemy);
                            if (enemy.life < 1) {
                                enemy.remove();
                            }
                        pierceLeft--;
                            break;
                    }
                }
            }
            else{
                GApple target = null;
                for (int i = 0; i < GlobalVariables.enemies.size(); i++) {
                    if (!hit.contains(GlobalVariables.enemies.get(i))){
                        target = GlobalVariables.enemies.get(i);
                        break;
                    }
                }
                if (target == null){
                    remove();
                }
                else{
                    if (pierceLeft < 1){
                        pierceLeft--;
                        if (pierceLeft < -10){
                            remove();
                        }
                    }
                    else {
                        GLine l = new GLine(hit.get(hit.size() - 1).getX() - this.getX(), hit.get(hit.size() - 1).getY() - this.getY(), target.getX() - this.getX(), target.getY() - this.getY());
                        l.setColor(Color.yellow);
                        add(l);
                        target.life -=Math.pow(1.5,pierceLeft)*target.vunrablility;
                        hit.add(target);
                        if (target.life < 1){
                            target.remove();
                        }
                        pierceLeft--;
                    }
                }
            }

        }
        else if (type == 5){
            if (pierceLeft == pierce()){
                moveTowards(target.getX(), target.getY(),lvl);
            }
            else{
                moveSteps(lvl);
            }
            for (int i = 0; i < GlobalVariables.enemies.size(); i++) {
                GApple enemy = GlobalVariables.enemies.get(i);
                if (isTouching(enemy)){
                    if (pierceLeft > 0) {
                        if (lvl > 2) {
                            enemy.life -= Math.pow(lvl - 2, 2);
                        }
                        enemy.frozen += 25 * lvl;
                        if (enemy.vunrablility < 1 + (0.2*lvl)){
                            enemy.vunrablility = 1 + (0.2*lvl);
                        }
                        hit.add(enemy);
                        if (enemy.life < 1) {
                            enemy.remove();
                            i--;
                        }
                    }
                    pierceLeft--;
                    if (pierceLeft < 1){
                        this.remove();
                    }
                }
            }
        }
        else if (type == 7){
            double x = owner.getX()+owner.getWidth()/2-getWidth()/2;
            double y = owner.getY()+owner.getHeight()/2-getHeight()/2;
            if (out){
                if (pierceLeft < 0) {
                    pierceLeft = 300;
                    hit.clear();
                }
                if (pierceLeft < 25){
                    moveTowards(x,y+100,lvl*2);
                }
                else if (pierceLeft < 50){
                    moveTowards(x-38,y+75,lvl*2);
                }
                else if (pierceLeft < 75){
                    moveTowards(x-76,y+50,lvl*2);
                }
                else if (pierceLeft < 100){
                    moveTowards(x-76,y,lvl*2);
                }
                else if (pierceLeft < 125){
                    moveTowards(x-76,y-50,lvl*2);
                }
                else if (pierceLeft < 150){
                    moveTowards(x-38,y-75,lvl*2);
                }
                else if (pierceLeft < 175){
                    moveTowards(x,y-100,lvl*2);
                }
                else if (pierceLeft < 200){
                    moveTowards(x+38,y-75,lvl*2);
                }
                else if (pierceLeft < 225){
                    moveTowards(x+76,y-50,lvl*2);
                }
                else if (pierceLeft < 250){
                    moveTowards(x+76,y,lvl*2);
                }
                else if (pierceLeft < 275){
                    moveTowards(x+76,y+50,lvl*2);
                }
                else{
                    moveTowards(x+38,y+75,lvl*2);
                }
            }
            else {
                if (pierceLeft < 0) {
                    pierceLeft = 300;
                    hit.clear();
                }
                if (pierceLeft < 50) {
                    moveTowards(x, y + 50, lvl);
                }
                else if (pierceLeft < 100) {
                    moveTowards(x + 38, y + 25, lvl);
                }
                else if (pierceLeft < 150) {
                    moveTowards(x + 38, y - 25, lvl);
                }
                else if (pierceLeft < 200) {
                    moveTowards(x, y - 50, lvl);
                }
                else if (pierceLeft < 250) {
                    moveTowards(x - 38, y - 25, lvl);
                }
                else {
                    moveTowards(x - 38, y + 25, lvl);
                }
            }
            for (int i = 0; i < GlobalVariables.enemies.size(); i++) {
                GApple enemy = GlobalVariables.enemies.get(i);
                if (isTouching(enemy)){
                        enemy.life-=lvl*2*((lvl/3)+1)*enemy.vunrablility;
                        hit.add(enemy);
                        if (enemy.life < 1) {
                            enemy.remove();
                            i--;
                        }
                }
            }
            pierceLeft-=lvl;
        }
        else if (type == 8){
            if (pierceLeft == pierce()){
                moveTowards(target.getX(), target.getY(),lvl*2);
            }
            else{
                moveSteps(lvl*2);
            }
            for (int i = 0; i < GlobalVariables.enemies.size(); i++) {
                GApple enemy = GlobalVariables.enemies.get(i);
                if (isTouching(enemy)){
                    if (pierceLeft > 0) {
                        enemy.life -= (lvl + (lvl/2) + (lvl/3)) *enemy.vunrablility;
                        hit.add(enemy);
                        if (enemy.life < 1) {
                            enemy.remove();
                            i--;
                        }
                    }
                    pierceLeft--;
                    if (pierceLeft < 1){
                        this.remove();
                    }
                }
            }
        }
        else if (type == 10){
            if (targets == null){
                for (int i = 0; i < GlobalVariables.enemies.size(); i++) {
                    GApple enemy = GlobalVariables.enemies.get(i);
                    if (isTouching(enemy)){
                        if (pierceLeft*enemy.vunrablility > enemy.life) {
                            enemy.life-=enemy.life;
                            enemy.remove();
                            i--;
                            pierceLeft-=enemy.life/enemy.vunrablility;
                        }
                        else{
                            enemy.life-=pierceLeft*enemy.vunrablility;
                            this.remove();
                            break;
                        }
                    }
                }
            }
            else {
                moveTowards(targets.getX()+targets.getWidth()/2,targets.getY()+targets.getHeight()/2,lvl);
                if (calculateDistance(targets.getX()+targets.getWidth()/2,targets.getY()+targets.getHeight()/2) < 10){
                    targets = null;
                }
            }
        }
        if (type != 1 && type != 7 && type != 10) {
            if (target.life < 1) {
                if (pierceLeft == pierce()) {
                    remove();
                }
            }
        }
        if (this.getX() < -50 || this.getX() > 1050 || this.getY() < -50 || this.getY() > 550){
            remove();
        }
    }
    public GProjectile(int type, int lvl, GApple target, GTile starter){
        owner = starter;
        GlobalVariables.projectiles.add(this);
        this.lvl = lvl;
        this.type = type;
        this.target = target;
        pierceLeft = pierce();
        v.setFilled(true);
        Color z;
        switch (type) {
            case 2 -> z = Color.red;
            case 3 -> z = Color.blue;
            case 4 -> z = Color.yellow;
            case 8 -> z = new Color(125, 25, 0);
            default -> z = Color.cyan;
        }
        v.setFillColor(z);
        add(v);
        addToScreen(starter);
    }
    public GProjectile(int lvl, int direction, GTile starter){
        owner = starter;
        GlobalVariables.projectiles.add(this);
        type = 1;
        this.lvl = lvl;
        if (direction == 1){
            xAmount = 0;
            yAmount = 1;
        }
        else if (direction == 2){
            yAmount = 0.4;
            xAmount = 0.6;
        }
        else if (direction == 3){
            yAmount = -0.4;
            xAmount = 0.6;
        }
        else if (direction == 4){
            yAmount = -1;
            xAmount = 0;
        }
        else if (direction == 5){
            yAmount = -0.4;
            xAmount = -0.6;
        }
        else{
            xAmount = -0.6;
            yAmount = 0.4;
        }
        pierceLeft = 10*lvl;
        v.setFilled(true);
        v.setFillColor(Color.green);
        add(v);
        addToScreen(starter);
    }
    public GProjectile(int lvl, GTile starter, boolean outside){
        v.setFillColor(new Color(50, 0, 125));
        v.setFilled(true);
        add(v);
        type = 7;
        this.lvl = lvl;
        owner = starter;
        addToScreen(starter);
        out = outside;
        pierceLeft = 300;
    }
    public GProjectile(int lvl, GTile target, GTile starter){
        owner = starter;
        GlobalVariables.projectiles.add(this);
        this.lvl = lvl;
        type  =10;
        targets = target;
        pierceLeft = pierce();
        v.setFilled(true);
        v.setFillColor(new Color(150,255,150));
        add(v);
        addToScreen(starter);
    }
    private boolean isTouching(GApple enemy){
        return (calculateDistance(enemy.getX(),enemy.getY()) < 25 && !hit.contains(enemy));
    }
    private int pierce(){
        if (type == 2){
            return 2*lvl;
        }
        else if (type == 3){
            return 1;
        }
        else if (type == 4){
            return 3+lvl;
        }
        else if (type == 10){
            return 6*lvl;
        }
        else {
          return 2 + (lvl/2);
        }
    }
    public double calculateDistance(double x, double y){
        return Math.sqrt(Math.pow(x-getX(),2)+Math.pow(y-getY(),2));
    }
    private void addToScreen(GTile s){
        GlobalVariables.screen.add(this,s.getX()+s.getWidth()/2-this.getWidth()/2,s.getY()+s.getHeight()/2-this.getHeight()/2);
    }
    void remove(){
        GlobalVariables.projectiles.remove(this);
        GlobalVariables.screen.remove(this);
        owner.projectiles.remove(this);
    }
}
